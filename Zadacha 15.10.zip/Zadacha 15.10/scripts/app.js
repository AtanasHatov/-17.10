const reloadBtn = document.getElementById('reloadBtn');
const activityContainer = document.querySelector('.activity-card');
const activityText = document.getElementById('activityText');
const activityType = document.getElementById('activityType');

reloadBtn.addEventListener('click', loadActivity);

async function loadActivity() {

  activityContainer.style.display = 'none';
  reloadBtn.disabled = true;
  reloadBtn.textContent = ' Зареждане...';

  try {
    const response = await fetch('https://www.boredapi.com/api/activity/');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();

    activityText.textContent = data.activity;
    activityType.textContent = `Тип: ${data.type}, участници: ${data.participants}`;
    activityContainer.style.display = 'block';

  } catch (err) {
    activityText.textContent = ` Грешка при зареждане: ${err.message}`;
    activityType.textContent = '';
    activityContainer.style.display = 'block';
  } finally {
    reloadBtn.disabled = false;
    reloadBtn.textContent = ' Дай ми идея!';
  }
}

loadActivity();